<?php
require_once 'auth.php';

// Basic admin stats
$totalUsers   = 0;
$totalCars    = 0;
$pendingCars  = 0;
$totalParts   = 0;
$pendingParts = 0;
$totalOrders  = 0;
$totalRevenue = 0.0;

try {
    $totalUsers = (int)$db->query("SELECT COUNT(*) FROM users")->fetchColumn();

    $totalCars = (int)$db->query("SELECT COUNT(*) FROM cars")->fetchColumn();
    $pendingCars = (int)$db->query("SELECT COUNT(*) FROM cars WHERE approval_status = 'pending'")->fetchColumn();

    $totalParts = (int)$db->query("SELECT COUNT(*) FROM spare_parts")->fetchColumn();
    $pendingParts = (int)$db->query("SELECT COUNT(*) FROM spare_parts WHERE approval_status = 'pending'")->fetchColumn();

    $totalOrders = (int)$db->query("SELECT COUNT(*) FROM orders")->fetchColumn();

    $totalRevenue = (float)$db->query("
        SELECT COALESCE(SUM(total_amount),0)
        FROM orders
        WHERE order_status NOT IN ('cancelled','refunded')
    ")->fetchColumn();
} catch (Exception $e) {
    // If something fails, show it instead of blank
    die("Admin dashboard DB error: " . h($e->getMessage()));
}

// Recent orders
$recentOrders = [];
try {
    $stmt = $db->query("
        SELECT order_id, buyer_id, total_amount, order_status, created_at
        FROM orders
        ORDER BY created_at DESC
        LIMIT 5
    ");
    $recentOrders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $recentOrders = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - CarHub</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body{margin:0;font-family:system-ui,-apple-system,"Segoe UI",sans-serif;background:#0f172a;color:#e5e7eb;}
        a{color:#a5b4fc;text-decoration:none;}a:hover{text-decoration:underline;}
        .topbar{display:flex;justify-content:space-between;align-items:center;padding:0.75rem 1.5rem;background:#020617;border-bottom:1px solid #111827;}
        .layout{display:flex;min-height:calc(100vh - 52px);}
        .sidebar{width:240px;background:#020617;border-right:1px solid #111827;padding:1.5rem 1rem;font-size:0.9rem;}
        .sidebar h3{font-size:0.9rem;color:#9ca3af;margin-bottom:0.5rem;}
        .sidebar ul{list-style:none;padding:0;margin:0;}
        .sidebar li{margin-bottom:0.35rem;}
        .sidebar a{display:block;padding:0.5rem 0.7rem;border-radius:0.5rem;color:#e5e7eb;}
        .sidebar a:hover{background:#111827;}
        .main{flex:1;padding:1.75rem 2rem;}
        .stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:1rem;margin-bottom:1.5rem;}
        .card{background:#020617;border:1px solid #111827;border-radius:0.75rem;padding:1rem;}
        .card h4{margin:0 0 0.4rem;color:#9ca3af;font-size:0.85rem;}
        .card p{margin:0;font-size:1.2rem;font-weight:700;}
        table{width:100%;border-collapse:collapse;font-size:0.86rem;}
        th,td{padding:0.5rem 0.4rem;border-bottom:1px solid #111827;text-align:left;}
        .badge{display:inline-block;padding:0.1rem 0.45rem;border-radius:999px;border:1px solid #374151;font-size:0.7rem;color:#9ca3af;}
    </style>
</head>
<body>

<header class="topbar">
    <div>🛠️ CarHub Admin</div>
    <div>
        <a href="../logout.php">Logout</a>
    </div>
</header>

<div class="layout">
    <aside class="sidebar">
        <h3>Admin Menu</h3>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="users.php">Users</a></li>
            <li><a href="cars-pending.php">Pending Cars</a></li>
            <li><a href="parts-pending.php">Pending Parts</a></li>
            <li><a href="cars.php">All Cars</a></li>
            <li><a href="parts.php">All Parts</a></li>
            <li><a href="orders.php">Orders</a></li>
            <li><a href="reviews.php">Reviews</a></li>
            <li><a href="reports.php">Reports</a></li>
            <li><a href="settings.php">Settings</a></li>
        </ul>
    </aside>

    <main class="main">
        <h1>Dashboard</h1>
        <p style="color:#9ca3af;margin-top:-0.5rem;">Platform overview</p>

        <section class="stats">
            <div class="card"><h4>Total users</h4><p><?php echo $totalUsers; ?></p></div>
            <div class="card"><h4>Cars</h4><p><?php echo $totalCars; ?></p><div style="color:#9ca3af;font-size:0.8rem;"><?php echo $pendingCars; ?> pending</div></div>
            <div class="card"><h4>Spare parts</h4><p><?php echo $totalParts; ?></p><div style="color:#9ca3af;font-size:0.8rem;"><?php echo $pendingParts; ?> pending</div></div>
            <div class="card"><h4>Orders</h4><p><?php echo $totalOrders; ?></p><div style="color:#9ca3af;font-size:0.8rem;">Revenue: ₵<?php echo number_format($totalRevenue,2); ?></div></div>
        </section>

        <section class="card">
            <h3 style="margin:0 0 0.75rem;">Recent orders</h3>
            <?php if (empty($recentOrders)): ?>
                <p style="color:#9ca3af;">No orders yet.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Order #</th>
                            <th>Buyer</th>
                            <th>Status</th>
                            <th>Total</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($recentOrders as $o): ?>
                        <tr>
                            <td>#<?php echo (int)$o['order_id']; ?></td>
                            <td><?php echo (int)$o['buyer_id']; ?></td>
                            <td><span class="badge"><?php echo h($o['order_status']); ?></span></td>
                            <td>₵<?php echo number_format($o['total_amount'],2); ?></td>
                            <td><?php echo h($o['created_at']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </section>
    </main>
</div>

</body>
</html>