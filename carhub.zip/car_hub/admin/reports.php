<?php
require_once 'auth.php'; // admin auth + $db + h()

error_reporting(E_ALL);
ini_set('display_errors', 1);

$monthlyOrders = [];
$topSellers    = [];
$errors        = [];

try {
    $sql = "SELECT DATE_FORMAT(created_at, '%Y-%m') AS ym,
                   COUNT(*) AS orders_count,
                   COALESCE(SUM(total_amount),0) AS revenue
            FROM orders
            WHERE order_status NOT IN ('cancelled','refunded')
            GROUP BY ym
            ORDER BY ym DESC
            LIMIT 6";
    $stmt = $db->query($sql);
    $monthlyOrders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $errors[] = "Monthly orders query error: " . $e->getMessage();
}

try {
    // Top sellers by earnings from order_items
    $sql = "SELECT seller_id,
                   COALESCE(SUM(subtotal),0) AS earnings,
                   COUNT(DISTINCT order_id) AS orders_count
            FROM order_items
            GROUP BY seller_id
            ORDER BY earnings DESC
            LIMIT 5";
    $stmt = $db->query($sql);
    $topSellers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $errors[] = "Top sellers query error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reports - CarHub Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body{margin:0;font-family:system-ui,-apple-system,"Segoe UI",sans-serif;background:#0f172a;color:#e5e7eb;}
        a{color:#a5b4fc;text-decoration:none;}a:hover{text-decoration:underline;}
        .topbar{display:flex;justify-content:space-between;align-items:center;padding:0.75rem 1.5rem;background:#020617;border-bottom:1px solid #111827;}
        .layout{display:flex;min-height:calc(100vh - 52px);}
        .sidebar{width:240px;background:#020617;border-right:1px solid #111827;padding:1.5rem 1rem;font-size:0.9rem;}
        .sidebar ul{list-style:none;padding:0;margin:0;}
        .sidebar li{margin-bottom:0.35rem;}
        .sidebar a{display:block;padding:0.5rem 0.7rem;border-radius:0.5rem;color:#e5e7eb;}
        .sidebar a:hover{background:#111827;}
        .main{flex:1;padding:1.75rem 2rem;}
        .page-title{font-size:1.4rem;margin-bottom:0.25rem;}
        .page-subtitle{font-size:0.9rem;color:#9ca3af;margin-bottom:1.5rem;}
        .card{background:#020617;border-radius:0.75rem;padding:1rem 1.1rem;border:1px solid #111827;margin-bottom:1rem;max-width:900px;}
        table{width:100%;border-collapse:collapse;font-size:0.86rem;}
        th,td{padding:0.5rem 0.4rem;border-bottom:1px solid #111827;text-align:left;}
        .error-box{background:#7f1d1d;color:#fee2e2;border:1px solid #991b1b;border-radius:0.75rem;padding:0.75rem;margin-bottom:1rem;max-width:900px;}
    </style>
</head>
<body>

<header class="topbar">
    <div>🛠️ CarHub Admin</div>
    <div>
        <a href="dashboard.php">Dashboard</a> ·
        <a href="../logout.php">Logout</a>
    </div>
</header>

<div class="layout">
    <aside class="sidebar">
        <h3>Admin Menu</h3>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="users.php">Users</a></li>
            <li><a href="cars-pending.php">Pending Cars</a></li>
            <li><a href="parts-pending.php">Pending Parts</a></li>
            <li><a href="cars.php">All Cars</a></li>
            <li><a href="parts.php">All Parts</a></li>
            <li><a href="orders.php">Orders</a></li>
            <li><a href="reviews.php">Reviews</a></li>
            <li><a href="reports.php">Reports</a></li>
            <li><a href="settings.php">Settings</a></li>
        </ul>
    </aside>

    <main class="main">
        <h1 class="page-title">Reports</h1>
        <p class="page-subtitle">Quick performance overview.</p>

        <?php if (!empty($errors)): ?>
            <div class="error-box">
                <?php foreach ($errors as $err): ?>
                    <div><?php echo h($err); ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <section class="card">
            <h2 style="margin-top:0;">Revenue & orders by month (last 6)</h2>
            <?php if (empty($monthlyOrders)): ?>
                <p style="color:#9ca3af;">No order data yet.</p>
            <?php else: ?>
                <table>
                    <thead>
                    <tr>
                        <th>Month</th>
                        <th>Orders</th>
                        <th>Revenue (₵)</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($monthlyOrders as $m): ?>
                        <tr>
                            <td><?php echo h($m['ym']); ?></td>
                            <td><?php echo (int)$m['orders_count']; ?></td>
                            <td>₵<?php echo number_format((float)$m['revenue'], 2); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </section>

        <section class="card">
            <h2 style="margin-top:0;">Top sellers (by earnings)</h2>
            <?php if (empty($topSellers)): ?>
                <p style="color:#9ca3af;">No seller data yet.</p>
            <?php else: ?>
                <table>
                    <thead>
                    <tr>
                        <th>Seller ID</th>
                        <th>Orders</th>
                        <th>Earnings (₵)</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($topSellers as $s): ?>
                        <tr>
                            <td><?php echo (int)$s['seller_id']; ?></td>
                            <td><?php echo (int)$s['orders_count']; ?></td>
                            <td>₵<?php echo number_format((float)$s['earnings'], 2); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </section>
    </main>
</div>

</body>
</html>