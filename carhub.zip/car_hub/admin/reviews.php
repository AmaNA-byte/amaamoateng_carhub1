<?php
// admin/reviews.php
require_once 'auth.php'; // ✅ correct: auth.php is inside /admin

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Handle delete review
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['review_id'])) {
    $reviewId = (int)$_POST['review_id'];

    if ($reviewId > 0) {
        try {
            $stmt = $db->prepare("DELETE FROM reviews WHERE review_id = :id");
            $stmt->execute([':id' => $reviewId]);
        } catch (Exception $e) {
            die("Delete failed: " . h($e->getMessage()));
        }
    }

    header('Location: reviews.php');
    exit;
}

// Load reviews
try {
    $stmt = $db->query("
        SELECT 
            r.review_id,
            r.order_id,
            r.rating,
            r.comment,
            r.created_at,
            u1.first_name AS reviewer_first,
            u1.last_name  AS reviewer_last,
            u2.first_name AS reviewee_first,
            u2.last_name  AS reviewee_last
        FROM reviews r
        LEFT JOIN users u1 ON r.reviewer_id = u1.user_id
        LEFT JOIN users u2 ON r.reviewee_id = u2.user_id
        ORDER BY r.created_at DESC
    ");
    $reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    die("Reviews query failed: " . h($e->getMessage()));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reviews - Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body{margin:0;font-family:system-ui,-apple-system,"Segoe UI",sans-serif;background:#0f172a;color:#e5e7eb;}
        a{color:#a5b4fc;text-decoration:none;}a:hover{text-decoration:underline;}

        .topbar{
            display:flex;justify-content:space-between;align-items:center;
            padding:0.75rem 1.5rem;background:#020617;border-bottom:1px solid #111827;
        }
        .layout{display:flex;min-height:calc(100vh - 52px);}

        .sidebar{
            width:240px;background:#020617;border-right:1px solid #111827;
            padding:1.5rem 1rem;font-size:0.9rem;
        }
        .sidebar ul{list-style:none;padding:0;margin:0;}
        .sidebar li{margin-bottom:0.35rem;}
        .sidebar a{
            display:block;padding:0.5rem 0.7rem;border-radius:0.5rem;color:#e5e7eb;
        }
        .sidebar a:hover{background:#111827;}

        .main{flex:1;padding:1.75rem 2rem;}
        .page-title{font-size:1.4rem;margin-bottom:0.25rem;}
        .page-subtitle{font-size:0.9rem;color:#9ca3af;margin-bottom:1.5rem;}

        .card{
            background:#020617;border-radius:0.75rem;
            padding:1rem 1.1rem;border:1px solid #111827;
        }
        .review{
            border-bottom:1px solid #111827;
            padding:0.75rem 0;
        }
        .review:last-child{border-bottom:none;}
        .meta{font-size:0.85rem;color:#9ca3af;margin-bottom:0.3rem;}
        .rating{color:#facc15;}

        .btn-delete{
            padding:0.35rem 0.9rem;border-radius:999px;border:none;
            font-size:0.8rem;cursor:pointer;
            background:#7f1d1d;color:#fee2e2;
        }
    </style>
</head>
<body>

<header class="topbar">
    <div>🛠️ CarHub Admin</div>
    <div>
        <a href="dashboard.php">Dashboard</a> ·
        <a href="../logout.php">Logout</a>
    </div>
</header>

<div class="layout">
    <aside class="sidebar">
        <h3>Admin Menu</h3>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="users.php">Users</a></li>
            <li><a href="cars-pending.php">Pending Cars</a></li>
            <li><a href="parts-pending.php">Pending Parts</a></li>
            <li><a href="cars.php">All Cars</a></li>
            <li><a href="parts.php">All Parts</a></li>
            <li><a href="orders.php">Orders</a></li>
            <li><a href="reviews.php">Reviews</a></li>
            <li><a href="reports.php">Reports</a></li>
            <li><a href="settings.php">Settings</a></li>
        </ul>
    </aside>

    <main class="main">
        <h1 class="page-title">Reviews</h1>
        <p class="page-subtitle">View and moderate all user reviews.</p>

        <section class="card">
            <?php if (empty($reviews)): ?>
                <p style="color:#9ca3af;">No reviews yet.</p>
            <?php else: ?>
                <?php foreach ($reviews as $r): ?>
                    <div class="review">
                        <div class="meta">
                            From: <?php echo h(trim(($r['reviewer_first'] ?? '').' '.($r['reviewer_last'] ?? ''))); ?>
                            → To: <?php echo h(trim(($r['reviewee_first'] ?? '').' '.($r['reviewee_last'] ?? ''))); ?>
                            · Order #<?php echo (int)$r['order_id']; ?>
                            · <span class="rating"><?php echo str_repeat('★', (int)$r['rating']); ?></span>
                            (<?php echo (int)$r['rating']; ?>/5)
                            · <?php echo h($r['created_at']); ?>
                        </div>

                        <div style="font-size:0.9rem;margin-bottom:0.4rem;">
                            <?php echo nl2br(h($r['comment'])); ?>
                        </div>

                        <form method="post">
                            <input type="hidden" name="review_id" value="<?php echo (int)$r['review_id']; ?>">
                            <button type="submit" class="btn-delete"
                                    onclick="return confirm('Delete this review?');">
                                Delete
                            </button>
                        </form>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </section>
    </main>
</div>

</body>
</html>