Options -Indexes
<FilesMatch "\.(php|phtml|php3|php4|php5|phar)$">
  Deny from all
</FilesMatch>\