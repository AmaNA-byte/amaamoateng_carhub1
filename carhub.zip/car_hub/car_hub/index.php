<?php
session_start();

$isLoggedIn = isset($_SESSION['user_id']);
$role = $_SESSION['role'] ?? null;

// ✅ Decide Start Selling destination safely
$startSellingLink = 'register.php';
if ($isLoggedIn) {
    if (in_array($role, ['seller', 'buyer_seller', 'admin'], true)) {
        $startSellingLink = 'seller/add-car.php';
    } else {
        // buyer-only account: send them to seller dashboard (you can later show a message there)
        $startSellingLink = 'seller/dashboard.php';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CarHub – Buy & Sell Cars and Spare Parts</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            background: #0f172a;
            color: #e5e7eb;
        }
        a { text-decoration: none; color: inherit; }
        .page { min-height: 100vh; display: flex; flex-direction: column; }

        .navbar {
            display: flex; justify-content: space-between; align-items: center;
            padding: 1rem 7vw;
            background: rgba(15, 23, 42, 0.95);
            border-bottom: 1px solid #111827;
            position: relative;
            z-index: 50;
        }

        .navbar-left { display: flex; align-items: center; gap: 0.6rem; }
        .logo-mark {
            width: 36px; height: 36px; border-radius: 999px;
            background: linear-gradient(135deg,#667eea,#764ba2);
            display: flex; align-items: center; justify-content: center;
            font-weight: 700; color: white;
        }
        .logo-text { display:flex; flex-direction:column; line-height: 1.05; }
        .logo-text span:first-child { font-weight: 700; }
        .logo-text span:last-child { font-size: 12px; color: #9ca3af; }

        .nav-links { display: flex; gap: 1rem; font-size: 0.95rem; }
        .nav-links a { padding: 0.3rem 0.6rem; border-radius: 999px; color: #9ca3af; }
        .nav-links a:hover { background: rgba(148,163,184,0.15); color: #e5e7eb; }

        .nav-auth { display: flex; gap: 0.75rem; }
        .btn-nav-ghost {
            padding: 0.45rem 0.9rem;
            border-radius: 999px;
            border: 1px solid rgba(156,163,175,0.4);
            font-size: 0.85rem;
        }
        .btn-nav-primary {
            padding: 0.45rem 1rem;
            border-radius: 999px;
            background: linear-gradient(135deg,#667eea,#764ba2);
            font-size: 0.85rem;
            font-weight: 600;
            color: white;
        }

        /* ---------------- HERO WITH VIDEO BG ---------------- */
        .hero {
            flex: 1;
            position: relative;
            overflow: hidden;
            padding: 4rem 7vw;
            display: grid;
            grid-template-columns: 1.1fr 1fr;
            gap: 3rem;
            min-height: calc(100vh - 72px); /* keeps it tall even with navbar */
        }
        @media (max-width: 900px) { .hero { grid-template-columns: 1fr; } }

        /* Video layer */
        .hero video.bg-video{
            position: absolute;
            inset: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            z-index: 1;
            filter: saturate(1.05) contrast(1.05);
        }

        /* Overlay layer (makes text readable + keeps your original vibe) */
        .hero .hero-overlay{
            position: absolute;
            inset: 0;
            z-index: 2;
            background:
                radial-gradient(circle at top left, rgba(129,140,248,0.28), transparent 55%),
                radial-gradient(circle at bottom, rgba(244,114,182,0.18), transparent 55%),
                linear-gradient(to bottom, rgba(2,6,23,0.65), rgba(2,6,23,0.88));
        }

        /* Content layer */
        .hero .hero-inner{
            position: relative;
            z-index: 3;
            display: grid;
            grid-template-columns: 1.1fr 1fr;
            gap: 3rem;
            align-items: center;
        }
        @media (max-width: 900px) {
            .hero .hero-inner { grid-template-columns: 1fr; }
        }

        .hero h1 {
            font-size: clamp(2rem, 3vw, 3.2rem);
            margin-bottom: 1rem;
        }
        .hero h1 span {
            background: linear-gradient(135deg,#a5b4fc,#f9a8d4);
            background-clip: text;
            -webkit-background-clip: text;
            color: transparent;
        }
        .hero p {
            color: #cbd5e1;
            max-width: 32rem;
            line-height: 1.6;
            margin-bottom: 1.5rem;
        }
        .hero-actions { display: flex; gap: 0.75rem; margin-bottom: 1.2rem; flex-wrap: wrap; }

        .btn-hero-primary {
            padding: 0.8rem 1.6rem;
            border-radius: 999px;
            background: linear-gradient(135deg,#667eea,#764ba2);
            color: white;
            font-weight: 600;
        }
        .btn-hero-ghost {
            padding: 0.8rem 1.4rem;
            border-radius: 999px;
            border: 1px solid rgba(148,163,184,0.6);
            color: #e5e7eb;
            backdrop-filter: blur(6px);
            background: rgba(2,6,23,0.25);
        }

        /* Optional right column (kept empty like you had, but made ready) */
        .hero-right {
            display: flex;
            justify-content: flex-end;
        }

        /* Mobile: hide video to save data + avoid autoplay quirks */
        @media (max-width: 768px) {
            .hero video.bg-video { display: none; }
            .hero{
                background:
                    radial-gradient(circle at top left, rgba(129,140,248,0.25), transparent 55%),
                    radial-gradient(circle at bottom, rgba(244,114,182,0.15), transparent 55%),
                    #020617;
            }
        }

        .site-footer {
            background: #020617;
            border-top: 1px solid #111827;
            padding: 1.3rem 7vw;
            font-size: 0.8rem;
            color: #9ca3af;
            position: relative;
            z-index: 50;
        }
        .site-footer-inner {
            display: flex; justify-content: space-between;
            flex-wrap: wrap; gap: 1rem;
        }
        .site-footer a:hover { color: #e5e7eb; }
    </style>
</head>
<body>

<div class="page">

<header class="navbar">
    <div class="navbar-left">
        <div class="logo-mark">C</div>
        <div class="logo-text">
            <span>CarHub</span>
            <span>Buy · Sell · Repair</span>
        </div>
    </div>

    <nav class="nav-links">
        <a href="index.php">Home</a>
        <a href="cars.php">Browse Cars</a>
        <a href="spare-parts.php">Spare Parts</a>
        <a href="additional/how-it-works.php">How it works</a>
    </nav>

    <div class="nav-auth">
        <?php if ($isLoggedIn): ?>
            <a href="dashboard/index.php" class="btn-nav-ghost">Dashboard</a>
            <a href="logout.php" class="btn-nav-primary">Logout</a>
        <?php else: ?>
            <a href="login.php" class="btn-nav-ghost">Login</a>
            <a href="register.php" class="btn-nav-primary">Get Started</a>
        <?php endif; ?>
    </div>
</header>

<section class="hero">
    <!-- ✅ VIDEO BACKGROUND -->
    <video class="bg-video" autoplay muted loop playsinline preload="metadata">
        <source src="assets/videos/hero.mp4" type="video/mp4">
    </video>

    <!-- ✅ DARK/GRADIENT OVERLAY -->
    <div class="hero-overlay"></div>

    <!-- ✅ HERO CONTENT -->
    <div class="hero-inner">
        <div>
            <h1>Buy & sell cars <span>without drama.</span></h1>
            <p>
                CarHub connects serious buyers and trusted sellers for both cars and spare parts.
                List your car in minutes, get real-time offers, and pay safely online.
            </p>

            <div class="hero-actions">
                <a href="cars.php" class="btn-hero-primary">Browse cars</a>

                <a href="<?php echo $startSellingLink; ?>" class="btn-hero-ghost">
                    Start selling →
                </a>
            </div>
        </div>

        <div class="hero-right"></div>
    </div>
</section>

<footer class="site-footer">
    <div class="site-footer-inner">
        <span>© <?php echo date('Y'); ?> CarHub. All rights reserved.</span>
        <span>
            <a href="additional/terms.php">Terms</a> ·
            <a href="additional/privacy.php">Privacy</a> ·
            <a href="additional/contact.php">Contact</a>
        </span>
    </div>
</footer>

</div>
</body>
</html>