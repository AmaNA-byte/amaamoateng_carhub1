<?php
// Email Configuration
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);
define('MAIL_USERNAME', 'akyaamansa4@gmail.com'); 
define('MAIL_PASSWORD', 'dydwdmcszmrihvhh');    
define('MAIL_FROM_ADDRESS', 'noreply@carhub.com');
define('MAIL_FROM_NAME', 'CarHub');
define('MAIL_ENCRYPTION', 'tls');
?>