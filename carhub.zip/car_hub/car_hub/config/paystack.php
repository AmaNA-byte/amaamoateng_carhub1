<?php
define('PAYSTACK_PUBLIC_KEY', 'pk_test_0ec4cc5322786d242d24ec55fa2d6d8502de1b69');
define('PAYSTACK_SECRET_KEY', 'sk_test_652802099760aae7b6211f99abaffce596143d34');
define('PAYSTACK_BASE_URL', 'https://api.paystack.co');
