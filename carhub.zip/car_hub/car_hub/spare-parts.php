<?php
session_start();
require_once 'config/database.php';
require_once 'config/session.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$database = new Database();
$db = $database->getConnection();

function h($v) {
    return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8');
}

// Filters
$q         = trim($_GET['q'] ?? '');
$category  = $_GET['category'] ?? '';
$condition = $_GET['condition'] ?? '';
$minPrice  = $_GET['min_price'] ?? '';
$maxPrice  = $_GET['max_price'] ?? '';

// Query from spare_parts table with JOIN to users
$sql = "SELECT
            sp.spare_part_id,
            sp.name,
            sp.category,
            sp.compatible_brands,
            sp.compatible_models,
            sp.price,
            sp.`condition`,
            sp.quantity,
            sp.description,
            u.user_id AS seller_id,
            u.first_name AS seller_first_name,
            u.last_name  AS seller_last_name,
            u.phone_number AS seller_phone,
            sp.created_at
        FROM spare_parts sp
        INNER JOIN users u ON sp.seller_id = u.user_id
        WHERE 1=1
        AND sp.status = 'available'
        AND sp.approval_status = 'approved'
        AND sp.quantity > 0";
$params = [];

if ($q !== '') {
    $sql .= " AND (sp.name LIKE :q OR sp.compatible_models LIKE :q OR sp.compatible_brands LIKE :q)";
    $params[':q'] = "%{$q}%";
}

if ($category !== '') {
    $sql .= " AND sp.category = :cat";
    $params[':cat'] = $category;
}

if ($condition !== '') {
    $sql .= " AND sp.`condition` = :cond";
    $params[':cond'] = $condition;
}

if ($minPrice !== '' && is_numeric($minPrice)) {
    $sql .= " AND sp.price >= :minPrice";
    $params[':minPrice'] = (float)$minPrice;
}

if ($maxPrice !== '' && is_numeric($maxPrice)) {
    $sql .= " AND sp.price <= :maxPrice";
    $params[':maxPrice'] = (float)$maxPrice;
}

$sql .= " ORDER BY sp.created_at DESC";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$parts = $stmt->fetchAll(PDO::FETCH_ASSOC);

$isLoggedIn = isset($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Browse Spare Parts - CarHub</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body{margin:0;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:#020617;color:#e5e7eb;}
        a{color:#a5b4fc;text-decoration:none;}a:hover{text-decoration:underline;}
        .topbar{display:flex;justify-content:space-between;align-items:center;padding:0.75rem 1.5rem;background:#020617;border-bottom:1px solid #111827;position:sticky;top:0;z-index:10;}
        .logo{font-weight:700;}
        .nav-links a{margin-right:1rem;font-size:0.9rem;color:#9ca3af;}
        .nav-links a:hover{color:#e5e7eb;}
        .nav-auth a{margin-left:0.75rem;font-size:0.9rem;}
        .btn-nav-primary{padding:0.4rem 0.9rem;border-radius:999px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;}
        .page{padding:1.5rem 7vw 2rem;}
        .page-title{font-size:1.5rem;margin-bottom:0.3rem;}
        .page-subtitle{font-size:0.9rem;color:#9ca3af;margin-bottom:1rem;}
        .filters{background:#020617;border:1px solid #111827;border-radius:0.75rem;padding:0.9rem 1rem;margin-bottom:1.5rem;display:flex;flex-wrap:wrap;gap:0.75rem;}
        .filters input,.filters select{background:#020617;border:1px solid #111827;border-radius:0.5rem;color:#e5e7eb;padding:0.4rem 0.6rem;font-size:0.85rem;}
        .filters label{font-size:0.8rem;color:#9ca3af;margin-right:0.25rem;}
        .filters-group{display:flex;flex-direction:column;font-size:0.8rem;}
        .btn-filter{padding:0.4rem 0.9rem;border-radius:999px;border:none;background:#111827;color:#e5e7eb;font-size:0.85rem;cursor:pointer;}
        .btn-filter:hover{filter:brightness(1.05);}
        .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:1rem;}
        .card{background:#020617;border-radius:0.75rem;border:1px solid #111827;padding:0.9rem 1rem;box-shadow:0 18px 40px rgba(15,23,42,0.8);}
        .card-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:0.4rem;}
        .part-title{font-size:1rem;font-weight:600;}
        .part-price{font-weight:600;font-size:0.95rem;}
        .meta{font-size:0.8rem;color:#9ca3af;margin-bottom:0.35rem;}
        .badge{display:inline-block;padding:0.1rem 0.45rem;border-radius:999px;border:1px solid #374151;font-size:0.7rem;margin-right:0.25rem;}
        .seller{font-size:0.8rem;color:#9ca3af;margin-top:0.4rem;}
        .card-footer{margin-top:0.6rem;display:flex;justify-content:space-between;align-items:center;font-size:0.8rem;}
        .btn{padding:0.45rem 0.9rem;border-radius:999px;border:none;font-size:0.85rem;cursor:pointer;}
        .btn-primary{background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;}
        .btn-disabled{background:#111827;color:#6b7280;cursor:not-allowed;}
        .empty{font-size:0.9rem;color:#9ca3af;margin-top:0.5rem;}
    </style>
</head>
<body>
<header class="topbar">
    <div class="logo">🧩 CarHub</div>
    <nav class="nav-links">
        <a href="index.php">Home</a>
        <a href="cars.php">Browse Cars</a>
        <a href="spare-parts.php">Spare Parts</a>
        <a href="additional/how-it-works.php">How it works</a>
    </nav>
    <div class="nav-auth">
        <?php if ($isLoggedIn): ?>
            <a href="dashboard/index.php">Dashboard</a>
            <a href="logout.php" class="btn-nav-primary">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a>
            <a href="register.php" class="btn-nav-primary">Get Started</a>
        <?php endif; ?>
    </div>
</header>

<main class="page">
    <h1 class="page-title">Browse spare parts</h1>
    <p class="page-subtitle">Only approved, available spare parts are shown.</p>

    <form method="get" class="filters">
        <div class="filters-group" style="flex:1 1 160px;">
            <label>Search (name/brand/model)</label>
            <input type="text" name="q" value="<?php echo h($q); ?>" placeholder="e.g. Transmission, Benz">
        </div>
        <div class="filters-group">
            <label>Category</label>
            <select name="category">
                <option value="">Any</option>
                <?php
                $cats = ['engine','transmission','brakes','suspension','electrical','body','interior','exhaust','cooling','fuel_system','other'];
                foreach ($cats as $c) {
                    $sel = ($category === $c) ? 'selected' : '';
                    echo "<option value=\"{$c}\" {$sel}>".ucfirst(str_replace('_',' ',$c))."</option>";
                }
                ?>
            </select>
        </div>
        <div class="filters-group">
            <label>Condition</label>
            <select name="condition">
                <option value="">Any</option>
                <?php
                $conds = ['new','used','refurbished'];
                foreach ($conds as $c) {
                    $sel = ($condition === $c) ? 'selected' : '';
                    echo "<option value=\"{$c}\" {$sel}>".ucfirst($c)."</option>";
                }
                ?>
            </select>
        </div>
        <div class="filters-group">
            <label>Min price (₵)</label>
            <input type="number" name="min_price" value="<?php echo h($minPrice); ?>" step="0.01">
        </div>
        <div class="filters-group">
            <label>Max price (₵)</label>
            <input type="number" name="max_price" value="<?php echo h($maxPrice); ?>" step="0.01">
        </div>
        <div style="align-self:flex-end;">
            <button type="submit" class="btn-filter">Apply filters</button>
        </div>
    </form>

    <?php if (empty($parts)): ?>
        <p class="empty">No spare parts found. Try adjusting your filters.</p>
    <?php else: ?>
        <div class="grid">
            <?php foreach ($parts as $p): ?>
                <article class="card">
                    <div class="card-header">
                        <div>
                            <div class="part-title"><?php echo h($p['name']); ?></div>
                            <div class="meta"><?php echo ucfirst($p['category']); ?></div>
                        </div>
                        <div class="part-price">₵<?php echo number_format($p['price'], 2); ?></div>
                    </div>

                    <div class="meta">
                        <?php if (!empty($p['compatible_brands'])): ?>
                            Brands: <?php echo h($p['compatible_brands']); ?><br>
                        <?php endif; ?>
                        <?php if (!empty($p['compatible_models'])): ?>
                            Models: <?php echo h($p['compatible_models']); ?>
                        <?php endif; ?>
                    </div>

                    <div class="meta">
                        <span class="badge"><?php echo ucfirst($p['condition']); ?></span>
                        <span class="badge">Qty: <?php echo (int)$p['quantity']; ?></span>
                    </div>

                    <?php if (!empty($p['description'])): ?>
                        <div class="meta">
                            <?php echo h(mb_strimwidth($p['description'], 0, 120, '...')); ?>
                        </div>
                    <?php endif; ?>

                    <div class="seller">
                        Seller: <?php echo h($p['seller_first_name'].' '.$p['seller_last_name']); ?>
                        <?php if (!empty($p['seller_phone'])): ?>
                            · <?php echo h($p['seller_phone']); ?>
                        <?php endif; ?>
                    </div>

                    <div class="card-footer">
                        <span style="font-size:0.75rem;color:#6b7280;">
                            Listed: <?php echo h(substr($p['created_at'], 0, 10)); ?>
                        </span>
                        <?php if ($isLoggedIn): ?>
                            <a href="cart/add.php?type=spare_part&id=<?php echo (int)$p['spare_part_id']; ?>" class="btn btn-primary">
                                Add to cart
                            </a>
                        <?php else: ?>
                            <a href="login.php" class="btn btn-disabled" title="Login to add to cart">
                                Login to buy
                            </a>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</main>
</body>
</html>