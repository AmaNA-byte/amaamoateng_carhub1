<?php
session_start();

// ✅ MUST include database class file
require_once 'config/database.php';

// ✅ session helpers are ok, but DO NOT force login here
require_once 'config/session.php';

// ✅ detect login only
$isLoggedIn = isset($_SESSION['user_id']);

error_reporting(E_ALL);
ini_set('display_errors', 1);

// ✅ now Database() will exist
$database = new Database();
$db = $database->getConnection();

function h($v) {
    return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8');
}

function short_text($text, $limit = 120) {
    $text = (string)$text;
    if (strlen($text) <= $limit) return $text;
    return substr($text, 0, $limit - 3) . '...';
}

// ----- filters from URL -----
$q         = trim($_GET['q'] ?? '');
$minPrice  = $_GET['min_price'] ?? '';
$maxPrice  = $_GET['max_price'] ?? '';
$bodyType  = $_GET['body_type'] ?? '';
$condition = $_GET['condition'] ?? '';

// ----- load data from cars table with JOIN to users -----
$cars  = [];
$error = '';

try {
    $sql = "SELECT
                c.car_id,
                c.brand,
                c.model,
                c.year,
                c.price,
                c.mileage,
                c.`condition`,
                c.body_type,
                c.transmission,
                c.fuel_type,
                c.color,
                c.description,
                c.status,
                u.user_id AS seller_id,
                u.first_name AS seller_first_name,
                u.last_name  AS seller_last_name,
                u.email      AS seller_email,
                u.phone_number AS seller_phone,
                c.created_at
            FROM cars c
            INNER JOIN users u ON c.seller_id = u.user_id
            WHERE 1=1
            AND c.status = 'available'
              AND c.approval_status = 'approved'";
    $params = [];

    if ($q !== '') {
        $sql .= " AND (c.brand LIKE :q OR c.model LIKE :q)";
        $params[':q'] = "%{$q}%";
    }

    if ($minPrice !== '' && is_numeric($minPrice)) {
        $sql .= " AND c.price >= :minPrice";
        $params[':minPrice'] = (float)$minPrice;
    }

    if ($maxPrice !== '' && is_numeric($maxPrice)) {
        $sql .= " AND c.price <= :maxPrice";
        $params[':maxPrice'] = (float)$maxPrice;
    }

    if ($bodyType !== '') {
        $sql .= " AND c.body_type = :bodyType";
        $params[':bodyType'] = $bodyType;
    }

    if ($condition !== '') {
        $sql .= " AND c.`condition` = :cond";
        $params[':cond'] = $condition;
    }

    $sql .= " ORDER BY c.created_at DESC";

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $cars = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $error = "Database error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Browse Cars - CarHub</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body{margin:0;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:#020617;color:#e5e7eb;}
        a{color:#a5b4fc;text-decoration:none;}a:hover{text-decoration:underline;}
        .topbar{display:flex;justify-content:space-between;align-items:center;padding:0.75rem 1.5rem;background:#020617;border-bottom:1px solid #111827;position:sticky;top:0;z-index:10;}
        .logo{font-weight:700;}
        .nav-links a{margin-right:1rem;font-size:0.9rem;color:#9ca3af;}
        .nav-links a:hover{color:#e5e7eb;}
        .nav-auth a{margin-left:0.75rem;font-size:0.9rem;}
        .btn-nav-primary{padding:0.4rem 0.9rem;border-radius:999px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;}
        .page{padding:1.5rem 7vw 2rem;}
        .page-title{font-size:1.5rem;margin-bottom:0.3rem;}
        .page-subtitle{font-size:0.9rem;color:#9ca3af;margin-bottom:1rem;}
        .error-box{background:#7f1d1d;padding:0.6rem 0.8rem;border-radius:0.5rem;margin-bottom:1rem;font-size:0.85rem;color:#fee2e2;}
        .filters{background:#020617;border:1px solid #111827;border-radius:0.75rem;padding:0.9rem 1rem;margin-bottom:1.5rem;display:flex;flex-wrap:wrap;gap:0.75rem;}
        .filters input,.filters select{background:#020617;border:1px solid #111827;border-radius:0.5rem;color:#e5e7eb;padding:0.4rem 0.6rem;font-size:0.85rem;}
        .filters label{font-size:0.8rem;color:#9ca3af;margin-right:0.25rem;}
        .filters-group{display:flex;flex-direction:column;font-size:0.8rem;}
        .btn-filter{padding:0.4rem 0.9rem;border-radius:999px;border:none;background:#111827;color:#e5e7eb;font-size:0.85rem;cursor:pointer;}
        .btn-filter:hover{filter:brightness(1.05);}
        .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:1rem;}
        .card{background:#020617;border-radius:0.75rem;border:1px solid #111827;padding:0.9rem 1rem;box-shadow:0 18px 40px rgba(15,23,42,0.8);}
        .card-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:0.4rem;}
        .car-title{font-size:1rem;font-weight:600;}
        .car-price{font-weight:600;font-size:0.95rem;}
        .meta{font-size:0.8rem;color:#9ca3af;margin-bottom:0.35rem;}
        .tag-row{font-size:0.75rem;color:#9ca3af;margin-bottom:0.4rem;}
        .badge{display:inline-block;padding:0.1rem 0.45rem;border-radius:999px;border:1px solid #374151;font-size:0.7rem;margin-right:0.25rem;}
        .seller{font-size:0.8rem;color:#9ca3af;margin-top:0.4rem;}
        .card-footer{margin-top:0.6rem;display:flex;justify-content:space-between;align-items:center;font-size:0.8rem;}
        .btn{padding:0.45rem 0.9rem;border-radius:999px;border:none;font-size:0.85rem;cursor:pointer;}
        .btn-primary{background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;}
        .btn-disabled{background:#111827;color:#6b7280;cursor:not-allowed;}
        .empty{font-size:0.9rem;color:#9ca3af;margin-top:0.5rem;}
    </style>
</head>
<body>
<header class="topbar">
    <div class="logo">🚗 CarHub</div>
    <nav class="nav-links">
        <a href="index.php">Home</a>
        <a href="cars.php">Browse Cars</a>
        <a href="spare-parts.php">Spare Parts</a>
        <!-- ✅ FIX: additional folder -->
        <a href="additional/how-it-works.php">How it works</a>
    </nav>
    <div class="nav-auth">
        <?php if ($isLoggedIn): ?>
            <a href="dashboard/index.php">Dashboard</a>
            <a href="logout.php" class="btn-nav-primary">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a>
            <a href="register.php" class="btn-nav-primary">Get Started</a>
        <?php endif; ?>
    </div>
</header>

<main class="page">
    <h1 class="page-title">Browse cars</h1>
    <p class="page-subtitle">Only approved, available cars are shown.</p>

    <?php if ($error): ?>
        <div class="error-box"><?php echo h($error); ?></div>
    <?php endif; ?>

    <form method="get" class="filters">
        <div class="filters-group" style="flex:1 1 160px;">
            <label>Search (brand/model)</label>
            <input type="text" name="q" value="<?php echo h($q); ?>" placeholder="e.g. Benz, Corolla">
        </div>
        <div class="filters-group">
            <label>Min price (₵)</label>
            <input type="number" name="min_price" value="<?php echo h($minPrice); ?>" step="0.01">
        </div>
        <div class="filters-group">
            <label>Max price (₵)</label>
            <input type="number" name="max_price" value="<?php echo h($maxPrice); ?>" step="0.01">
        </div>
        <div class="filters-group">
            <label>Body type</label>
            <select name="body_type">
                <option value="">Any</option>
                <?php
                $bodyTypes = ['sedan','suv','coupe','hatchback','truck','van','convertible','wagon'];
                foreach ($bodyTypes as $bt) {
                    $sel = ($bodyType === $bt) ? 'selected' : '';
                    echo "<option value=\"{$bt}\" {$sel}>".ucfirst($bt)."</option>";
                }
                ?>
            </select>
        </div>
        <div class="filters-group">
            <label>Condition</label>
            <select name="condition">
                <option value="">Any</option>
                <?php
                $conds = ['new','used','refurbished'];
                foreach ($conds as $c) {
                    $sel = ($condition === $c) ? 'selected' : '';
                    echo "<option value=\"{$c}\" {$sel}>".ucfirst($c)."</option>";
                }
                ?>
            </select>
        </div>
        <div style="align-self:flex-end;">
            <button type="submit" class="btn-filter">Apply filters</button>
        </div>
    </form>

    <?php if (!$error && empty($cars)): ?>
        <p class="empty">No cars found. Try adjusting your filters.</p>
    <?php elseif (!$error): ?>
        <div class="grid">
            <?php foreach ($cars as $car): ?>
                <article class="card">
                    <div class="card-header">
                        <div>
                            <div class="car-title"><?php echo h($car['brand'].' '.$car['model']); ?></div>
                            <div class="meta">Year <?php echo h($car['year']); ?></div>
                        </div>
                        <div class="car-price">₵<?php echo number_format($car['price'], 2); ?></div>
                    </div>

                    <div class="tag-row">
                        <span class="badge"><?php echo ucfirst($car['condition']); ?></span>
                        <span class="badge"><?php echo ucfirst($car['body_type']); ?></span>
                        <span class="badge"><?php echo ucfirst($car['transmission']); ?></span>
                        <span class="badge"><?php echo ucfirst($car['fuel_type']); ?></span>
                    </div>

                    <?php if (!empty($car['mileage'])): ?>
                        <div class="meta">Mileage: <?php echo (int)$car['mileage']; ?> km</div>
                    <?php endif; ?>
                    <?php if (!empty($car['color'])): ?>
                        <div class="meta">Color: <?php echo h($car['color']); ?></div>
                    <?php endif; ?>
                    <?php if (!empty($car['description'])): ?>
                        <div class="meta"><?php echo h(short_text($car['description'])); ?></div>
                    <?php endif; ?>

                    <div class="seller">
                        Seller: <?php echo h($car['seller_first_name'].' '.$car['seller_last_name']); ?>
                        <?php if (!empty($car['seller_phone'])): ?>
                            · <?php echo h($car['seller_phone']); ?>
                        <?php endif; ?>
                    </div>

                    <div class="card-footer">
                        <span style="font-size:0.75rem;color:#6b7280;">
                            Listed: <?php echo h(substr($car['created_at'], 0, 10)); ?>
                        </span>

                        <?php if ($isLoggedIn): ?>
                            <a href="cart/add.php?type=car&id=<?php echo (int)$car['car_id']; ?>" class="btn btn-primary">
                                Add to cart
                            </a>
                        <?php else: ?>
                            <a href="login.php" class="btn btn-disabled" title="Login to add to cart">
                                Login to buy
                            </a>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</main>
</body>
</html>