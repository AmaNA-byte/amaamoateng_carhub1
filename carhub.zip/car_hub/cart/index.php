<?php
// cart/index.php
session_start();
require_once '../config/database.php';
require_once '../config/session.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

$currentUserId = (int)$_SESSION['user_id'];

$database = new Database();
$db = $database->getConnection();

function h($v){ return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8'); }

// Get or create cart
function getOrCreateCartId(PDO $db, int $userId): int {
    $stmt = $db->prepare("SELECT cart_id FROM shopping_cart WHERE user_id = :uid LIMIT 1");
    $stmt->execute([':uid' => $userId]);
    $cartId = $stmt->fetchColumn();
    if ($cartId) return (int)$cartId;

    $stmt = $db->prepare("INSERT INTO shopping_cart (user_id, created_at, updated_at)
                           VALUES (:uid, NOW(), NOW())");
    $stmt->execute([':uid' => $userId]);
    return (int)$db->lastInsertId();
}

$cartId = getOrCreateCartId($db, $currentUserId);

// Handle quantity update / delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cart_item_id'])) {
    $cartItemId = (int)$_POST['cart_item_id'];
    $qty = (int)($_POST['quantity'] ?? 1);

    if ($qty <= 0) {
        $stmt = $db->prepare("DELETE FROM cart_items WHERE cart_item_id = :cid AND cart_id = :cart_id");
        $stmt->execute([':cid' => $cartItemId, ':cart_id' => $cartId]);
    } else {
        $stmt = $db->prepare("UPDATE cart_items SET quantity = :qty
                               WHERE cart_item_id = :cid AND cart_id = :cart_id");
        $stmt->execute([':qty' => $qty, ':cid' => $cartItemId, ':cart_id' => $cartId]);
    }

    header('Location: index.php');
    exit;
}

// Load cart items
$stmt = $db->prepare("
    SELECT cart_item_id, item_type, item_id, quantity
    FROM cart_items
    WHERE cart_id = :cart_id
");
$stmt->execute([':cart_id' => $cartId]);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Resolve item details
$total = 0;
foreach ($items as &$item) {
    $item['title'] = '';
    $item['meta'] = '';
    $item['unit_price'] = 0;
    $item['subtotal'] = 0;

    if ($item['item_type'] === 'car') {
        $q = $db->prepare("SELECT brand, model, year, price FROM cars WHERE car_id = :id");
        $q->execute([':id' => $item['item_id']]);
        if ($row = $q->fetch()) {
            $item['title'] = $row['brand'].' '.$row['model'];
            $item['meta'] = 'Year '.$row['year'];
            $item['unit_price'] = (float)$row['price'];
        }
    } else {
        $q = $db->prepare("SELECT name, category, price FROM spare_parts WHERE spare_part_id = :id");
        $q->execute([':id' => $item['item_id']]);
        if ($row = $q->fetch()) {
            $item['title'] = $row['name'];
            $item['meta'] = $row['category'];
            $item['unit_price'] = (float)$row['price'];
        }
    }

    $item['subtotal'] = $item['quantity'] * $item['unit_price'];
    $total += $item['subtotal'];
}
unset($item);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Cart - CarHub</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body{margin:0;font-family:system-ui,-apple-system,"Segoe UI",sans-serif;background:#0f172a;color:#e5e7eb;}
        a{color:#a5b4fc;text-decoration:none;}
        .topbar{display:flex;justify-content:space-between;align-items:center;padding:0.75rem 1.5rem;background:#020617;border-bottom:1px solid #111827;}
        .layout{display:flex;}
        .main{flex:1;padding:2rem;}
        table{width:100%;border-collapse:collapse;}
        th,td{padding:0.5rem;border-bottom:1px solid #111827;}
        .btn{padding:0.4rem 0.9rem;border-radius:999px;border:none;cursor:pointer;}
        .btn-primary{background:linear-gradient(135deg,#667eea,#764ba2);color:white;}
        .btn-secondary{background:#111827;color:#e5e7eb;}
    </style>
</head>
<body>

<header class="topbar">
    <div>🛒 CarHub · My Cart</div>
    <div>
        <a href="../index.php">Home</a> ·
        <a href="../cars.php">Browse Cars</a> ·
        <a href="../spare-parts.php">Spare Parts</a> ·
        <a href="../dashboard/index.php">Dashboard</a> ·
        <a href="../logout.php">Logout</a>
    </div>
</header>

<main class="main">
    <h1>My Cart</h1>

    <?php if (empty($items)): ?>
        <p>Your cart is empty.
            <a href="../cars.php">Browse Cars</a> or
            <a href="../spare-parts.php">Spare Parts</a>.
        </p>
    <?php else: ?>
        <table>
            <thead>
            <tr>
                <th>Item</th>
                <th>Details</th>
                <th>Price</th>
                <th>Qty</th>
                <th>Subtotal</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($items as $item): ?>
                <tr>
                    <td><?php echo h($item['title']); ?></td>
                    <td><?php echo h($item['meta']); ?></td>
                    <td>₵<?php echo number_format($item['unit_price'],2); ?></td>
                    <td>
                        <form method="post">
                            <input type="hidden" name="cart_item_id" value="<?php echo (int)$item['cart_item_id']; ?>">
                            <input type="number" name="quantity" value="<?php echo (int)$item['quantity']; ?>" style="width:60px;">
                    </td>
                    <td>₵<?php echo number_format($item['subtotal'],2); ?></td>
                    <td>
                            <button class="btn btn-secondary">Update / Remove</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

        <h3>Total: ₵<?php echo number_format($total,2); ?></h3>

        <a href="../cart/checkout.php" class="btn btn-primary">Proceed to checkout</a>
    <?php endif; ?>
</main>

</body>
</html>